"""
Instituição: Fatec Santo André - Mecatronica Industrial 
TCC: Sistema Automático para Coleta e Classificação de Ondas Cerebrais 
Autor: Diana Regina da Silva 
Descrição: Executa o script "modelo_RNA_testes_uso_joy" enquanto não for selecionado
a opção de parar a simulação na janela de uso automático
"""
from modelo_RNA_testes_uso_joy import aplicar_modelo

while True:
    aplicar_modelo(60)

            

